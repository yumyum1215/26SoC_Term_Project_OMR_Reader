#include "omr_ocr_preprocess.h"

static unsigned light(uint16_t pixel)
{
    unsigned r = pixel >> 11;
    unsigned g = (pixel >> 5) & 63U;
    unsigned b = pixel & 31U;
    unsigned maximum;
    r = (r << 3) | (r >> 2);
    g = (g << 2) | (g >> 4);
    b = (b << 3) | (b >> 2);
    maximum = r > g ? r : g;
    return maximum > b ? maximum : b;
}

int omr_ocr_preprocess(const uint16_t *frame, unsigned width, unsigned height,
                       unsigned stride, unsigned x0, unsigned y0,
                       unsigned x1, unsigned y1, unsigned mode, unsigned margin,
                       uint8_t *output)
{
    uint32_t histogram[256] = {0};
    uint64_t area, target, accumulated = 0;
    unsigned x, y, white = 255, denominator;
    if (!frame || !output || width == 0 || height == 0 || stride < width ||
        x0 >= x1 || y0 >= y1 || x1 > width || y1 > height ||
        mode > 1 || margin > 63)
        return -1;
    area = (uint64_t)(x1 - x0) * (y1 - y0);
    if (area > UINT32_MAX || (uint64_t)stride * height > UINT32_MAX)
        return -1;
    if (mode == 1) {
        for (y = y0; y < y1; ++y)
            for (x = x0; x < x1; ++x)
                ++histogram[light(frame[y * stride + x])];
        target = (area * 9 + 9) / 10;
        for (white = 0; white < 255; ++white) {
            accumulated += histogram[white];
            if (accumulated >= target)
                break;
        }
    }
    denominator = white > margin ? white - margin : 1;
    for (y = y0; y < y1; ++y) {
        for (x = x0; x < x1; ++x) {
            unsigned value = light(frame[y * stride + x]);
            if (mode == 0) {
                *output++ = (uint8_t)(255 - value);
            } else {
                unsigned delta = white > margin + value ? white - margin - value : 0;
                *output++ = (uint8_t)((delta * 255 + denominator / 2) / denominator);
            }
        }
    }
    return 0;
}
