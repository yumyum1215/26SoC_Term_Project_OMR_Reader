#ifndef OMR_FPGA_BACK_H
#define OMR_FPGA_BACK_H

#include "omr_grading.h"

/* 0 loaded, 1 file absent, -1 invalid file or accelerator busy. */
int omr_fpga_model_load_sd(void);
int omr_fpga_read_answer(const uint16_t *frame, const OmrBox *box, char text[4]);

#endif
