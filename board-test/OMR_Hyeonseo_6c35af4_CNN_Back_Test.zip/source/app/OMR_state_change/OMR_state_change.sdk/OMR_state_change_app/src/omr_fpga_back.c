#include "omr_fpga_back.h"

#include "ff.h"
#include "omr_cnn_accel.h"
#include "omr_ocr_preprocess.h"
#include "xparameters.h"

#include <string.h>

enum { CANVAS_WIDTH = 128, CANVAS_HEIGHT = 32, CONTENT_WIDTH = 120, CONTENT_HEIGHT = 28 };

static uint8_t image[OMR_ACCEL_PIXELS];
static uint8_t roi[OMR_WIDTH * OMR_HEIGHT];

static uint32_t crc32(const uint8_t *bytes, unsigned length)
{
    uint32_t crc = UINT32_MAX;
    for (unsigned i = 0; i < length; ++i) {
        crc ^= bytes[i];
        for (unsigned bit = 0; bit < 8; ++bit)
            crc = (crc >> 1) ^ (0xedb88320U & (0U - (crc & 1U)));
    }
    return ~crc;
}

int omr_fpga_model_load_sd(void)
{
    static omr_accel_model model;
    enum { SIZE = sizeof model.weights + sizeof model.biases + sizeof model.exponents };
    static uint8_t payload[SIZE];
    uint8_t header[12];
    UINT bytes;
    FIL file;

    const FRESULT open = f_open(&file, "0:/OMRCNN.BIN", FA_READ);
    if (open == FR_NO_FILE || open == FR_NO_PATH)
        return 1;
    if (open != FR_OK)
        return -1;
    const int ok = f_size(&file) == sizeof header + SIZE &&
                   f_read(&file, header, sizeof header, &bytes) == FR_OK && bytes == sizeof header &&
                   f_read(&file, payload, SIZE, &bytes) == FR_OK && bytes == SIZE;
    const FRESULT close = f_close(&file);
    if (!ok || close != FR_OK || memcmp(header, "OMRCNN01", 8) != 0)
        return -1;

    uint32_t expected;
    memcpy(&expected, header + 8, sizeof expected);
    if (crc32(payload, SIZE) != expected)
        return -1;
    memcpy(model.weights, payload, sizeof model.weights);
    memcpy(model.biases, payload + sizeof model.weights, sizeof model.biases);
    memcpy(model.exponents, payload + sizeof model.weights + sizeof model.biases, sizeof model.exponents);
    for (unsigned i = 0; i < sizeof model.exponents; ++i) {
        if (model.exponents[i] < -31 || model.exponents[i] > 31)
            return -1;
    }
    return omr_accel_load(XPAR_OMR_CNN_0_BASEADDR, &model);
}

static unsigned overlap(unsigned a0, unsigned a1, unsigned b0, unsigned b1)
{
    return (a1 < b1 ? a1 : b1) - (a0 > b0 ? a0 : b0);
}

/* Downsample by averaging the area covered by each destination pixel. */
static unsigned resized_pixel(unsigned x, unsigned y, unsigned width, unsigned height,
                              unsigned target_width, unsigned target_height)
{
    const unsigned left = x * width, right = left + width;
    const unsigned top = y * height, bottom = top + height;
    unsigned sum = 0;
    for (unsigned sy = top / target_height; sy * target_height < bottom; ++sy) {
        const unsigned y_area = overlap(top, bottom, sy * target_height, (sy + 1) * target_height);
        for (unsigned sx = left / target_width; sx * target_width < right; ++sx) {
            const unsigned x_area = overlap(left, right, sx * target_width, (sx + 1) * target_width);
            sum += roi[sy * width + sx] * x_area * y_area;
        }
    }
    return (sum + width * height / 2) / (width * height);
}

int omr_fpga_read_answer(const uint16_t *frame, const OmrBox *box, char text[4])
{
    text[0] = '\0';
    if (omr_ocr_preprocess(frame, OMR_WIDTH, OMR_HEIGHT, OMR_WIDTH,
                           box->left, box->top, box->right, box->bottom, 0, 0, roi) != 0)
        return OMR_REVIEW;

    const unsigned width = (unsigned)(box->right - box->left);
    const unsigned height = (unsigned)(box->bottom - box->top);
    unsigned target_width = width, target_height = height;
    if (width > CONTENT_WIDTH || height > CONTENT_HEIGHT) {
        if (width * CONTENT_HEIGHT > height * CONTENT_WIDTH) {
            target_width = CONTENT_WIDTH;
            target_height = (height * CONTENT_WIDTH + width / 2) / width;
        } else {
            target_width = (width * CONTENT_HEIGHT + height / 2) / height;
            target_height = CONTENT_HEIGHT;
        }
        if (!target_width)
            target_width = 1;
        if (!target_height)
            target_height = 1;
    }

    const unsigned left = (CANVAS_WIDTH - target_width) / 2;
    const unsigned top = (CANVAS_HEIGHT - target_height) / 2;
    memset(image, 0, sizeof image);
    for (unsigned y = 0; y < target_height; ++y) {
        for (unsigned x = 0; x < target_width; ++x) {
            image[(top + y) * CANVAS_WIDTH + left + x] =
                (uint8_t)resized_pixel(x, y, width, height, target_width, target_height);
        }
    }

    const int length = omr_accel_predict(XPAR_OMR_CNN_0_BASEADDR, image, 10000000U, text, NULL);
    if (length < 0)
        return OMR_REVIEW;
    if (length == 0)
        return OMR_BLANK;
    int answer = 0;
    for (int i = 0; i < length; ++i)
        answer = answer * 10 + (text[i] - '0');
    return answer;
}
