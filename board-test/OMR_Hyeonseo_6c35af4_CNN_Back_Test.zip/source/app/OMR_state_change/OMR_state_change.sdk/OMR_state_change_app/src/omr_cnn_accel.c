#include "omr_cnn_accel.h"

enum {
    CONTROL = 0x0000, STATUS = 0x0004, BIASES = 0x1000, EXPONENTS = 0x2000,
    INPUT = 0x4000, RESULTS = 0x8000, WEIGHTS = 0x10000, BUSY = 1, DONE = 2
};

static uint32_t read_word(uintptr_t base, unsigned offset)
{
    return *(volatile const uint32_t *)(base + offset);
}

static void write_word(uintptr_t base, unsigned offset, uint32_t value)
{
    *(volatile uint32_t *)(base + offset) = value;
}

int omr_accel_load(uintptr_t base, const omr_accel_model *model)
{
    unsigned i;

    if (read_word(base, STATUS) & BUSY)
        return -1;
    for (i = 0; i < sizeof model->weights; ++i)
        write_word(base, WEIGHTS + 4 * i, (uint8_t)model->weights[i]);
    for (i = 0; i < sizeof model->exponents; ++i) {
        write_word(base, BIASES + 4 * i, (uint32_t)model->biases[i]);
        write_word(base, EXPONENTS + 4 * i, (uint8_t)model->exponents[i]);
    }
    return 0;
}

int omr_accel_predict(uintptr_t base, const uint8_t ink[OMR_ACCEL_PIXELS],
                      uint32_t poll_limit, char text[4],
                      int32_t logits[OMR_ACCEL_STEPS][OMR_ACCEL_SYMBOLS])
{
    unsigned x, token, previous = 0, length = 0;

    text[0] = '\0';
    if (read_word(base, STATUS) & BUSY)
        return -3;
    for (x = 0; x < OMR_ACCEL_PIXELS; ++x)
        write_word(base, INPUT + 4 * x, (ink[x] * 128U + 127U) / 255U);
    write_word(base, CONTROL, 1);
    while (poll_limit && !(read_word(base, STATUS) & DONE))
        --poll_limit;
    if (!poll_limit)
        return -1;

    for (x = 0; x < OMR_ACCEL_STEPS; ++x) {
        int32_t maximum = INT32_MIN;
        unsigned best = 0;
        for (token = 0; token < OMR_ACCEL_SYMBOLS; ++token) {
            unsigned index = token * OMR_ACCEL_STEPS + x;
            int32_t value = (int32_t)read_word(base, RESULTS + 4 * index);
            if (logits)
                logits[x][token] = value;
            if (value > maximum) {
                maximum = value;
                best = token;
            }
        }
        if (best && best != previous) {
            if (length < 3)
                text[length] = (char)('0' + best - 1);
            ++length;
        }
        previous = best;
    }
    if (length > 3) {
        text[0] = '\0';
        return -2;
    }
    text[length] = '\0';
    return (int)length;
}
