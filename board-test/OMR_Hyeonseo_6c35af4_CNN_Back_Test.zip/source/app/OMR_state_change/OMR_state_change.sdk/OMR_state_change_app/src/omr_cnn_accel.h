#ifndef OMR_CNN_ACCEL_H
#define OMR_CNN_ACCEL_H

#include <stdint.h>

#define OMR_ACCEL_PIXELS 4096
#define OMR_ACCEL_STEPS 32
#define OMR_ACCEL_SYMBOLS 11

typedef struct {
    int8_t weights[21160];
    int32_t biases[123];
    int8_t exponents[123];
} omr_accel_model;

/* Load model registers once after FPGA configuration. Returns -1 if busy. */
int omr_accel_load(uintptr_t base, const omr_accel_model *model);

/* ink is a 32-high, 128-wide normalized ROI, white ink on black (0..255).
 * text keeps leading zeros. logits may be NULL, or a [32][11] score buffer.
 * Return: 0 blank, 1..3 digits, -1 timeout, -2 invalid length, -3 busy.
 * Access the AXI address through an uncached/device mapping.
 */
int omr_accel_predict(uintptr_t base, const uint8_t ink[OMR_ACCEL_PIXELS],
                      uint32_t poll_limit, char text[4],
                      int32_t logits[OMR_ACCEL_STEPS][OMR_ACCEL_SYMBOLS]);
#endif
