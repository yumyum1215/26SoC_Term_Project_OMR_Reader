#ifndef OMR_OCR_PREPROCESS_H
#define OMR_OCR_PREPROCESS_H
#include <stdint.h>

/* Standard R[15:11],G[10:5],B[4:0] RGB565 from the camera frame buffer.
 * x1,y1 are exclusive. Output has (x1-x0)*(y1-y0) bytes, white ink on black.
 * mode 0 = raw channel maximum, mode 1 = paper background suppression.
 * Returns 0 on success, -1 on invalid arguments. Caller resizes this ROI
 * with aspect ratio preserved to the model's 128x32 input.
 */
int omr_ocr_preprocess(const uint16_t *frame, unsigned width, unsigned height,
                       unsigned stride, unsigned x0, unsigned y0,
                       unsigned x1, unsigned y1, unsigned mode, unsigned margin,
                       uint8_t *output);
#endif
