`timescale 1ns/1ps
// INT8 CNN for the width-1.0 OMR digit-string model. One MAC is reused.
module omr_cnn_core (
    input  wire        clk,
    input  wire        resetn,
    input  wire        start,
    output wire        busy,
    output reg         done,
    input  wire        weight_we,
    input  wire [14:0] weight_waddr,
    input  wire [7:0]  weight_wdata,
    input  wire        bias_we,
    input  wire        exponent_we,
    input  wire [6:0]  parameter_waddr,
    input  wire [31:0] parameter_wdata,
    input  wire        input_we,
    input  wire [11:0] input_waddr,
    input  wire [7:0]  input_wdata,
    input  wire        result_re,
    input  wire [8:0]  result_raddr,
    output reg  signed [16:0] result_rdata
);
    localparam IDLE = 3'd0, LOAD_PARAM = 3'd1, BEGIN_PIXEL = 3'd2,
               ISSUE = 3'd3, DRAIN = 3'd4, WRITE_PIXEL = 3'd5;

    (* ram_style = "block" *) reg [7:0] feature_a [0:4095];
    (* ram_style = "block" *) reg [7:0] feature_b [0:8191];
    reg signed [31:0] biases [0:122];
    reg signed [5:0] exponents [0:122];
    (* ram_style = "block" *) reg signed [16:0] results [0:351];

    reg [2:0] state, layer;
    reg [5:0] out_c, out_x;
    reg [3:0] out_y;
    reg [4:0] in_c;
    reg [1:0] kx, ky;
    reg [8:0] tap;
    reg [14:0] weight_base;
    reg [6:0] parameter_index;
    reg [12:0] feature_waddr;

    reg [5:0] output_channels;
    reg [5:0] input_height;
    reg [7:0] input_width;
    reg [3:0] output_last_y;
    reg [5:0] output_last_x;
    reg [3:0] input_row_shift, input_plane_shift;
    reg stride_x_2, stride_y_2;
    reg [8:0] kernel_taps;
    wire final_layer = layer == 5;
    assign busy = state != IDLE;

    always @* begin
        output_last_x = 31;
        input_width = 32;
        input_row_shift = 5;
        stride_x_2 = 0;
        stride_y_2 = 1;
        case (layer)
            0: begin
                output_channels = 8;
                input_height = 32; output_last_y = 15; output_last_x = 63;
                input_width = 128; input_row_shift = 7; input_plane_shift = 12;
                stride_x_2 = 1; kernel_taps = 9;
            end
            1: begin
                output_channels = 16;
                input_height = 16; output_last_y = 7;
                input_width = 64; input_row_shift = 6; input_plane_shift = 10;
                stride_x_2 = 1; kernel_taps = 72;
            end
            2: begin
                output_channels = 24;
                input_height = 8; output_last_y = 3; input_plane_shift = 8;
                kernel_taps = 144;
            end
            3: begin
                output_channels = 32;
                input_height = 4; output_last_y = 1; input_plane_shift = 7;
                kernel_taps = 216;
            end
            4: begin
                output_channels = 32;
                input_height = 2; output_last_y = 1; input_plane_shift = 6;
                stride_y_2 = 0; kernel_taps = 288;
            end
            default: begin
                output_channels = 11;
                input_height = 2; output_last_y = 1; input_plane_shift = 6;
                stride_y_2 = 0; kernel_taps = 32;
            end
        endcase
    end

    wire signed [8:0] input_x = (stride_x_2 ? $signed({2'b00, out_x, 1'b0}) :
                                                            $signed({3'b000, out_x}))
                                  + $signed({7'b0, kx}) - (final_layer ? 9'sd0 : 9'sd1);
    wire signed [6:0] input_y = (stride_y_2 ? $signed({2'b00, out_y, 1'b0}) :
                                                            $signed({3'b000, out_y}))
                                  + $signed({5'b0, ky}) - (final_layer ? 7'sd0 : 7'sd1);
    wire in_bounds = input_x >= 0 && input_x < $signed({1'b0, input_width}) &&
                     input_y >= 0 && input_y < $signed({1'b0, input_height});
    wire [12:0] feature_raddr = ({8'b0, in_c} << input_plane_shift)
                                 + ({7'b0, input_y[5:0]} << input_row_shift)
                                 + {6'b0, input_x[6:0]};
    wire [14:0] weight_raddr = weight_base + {6'b0, tap};
    wire issue_last = tap == kernel_taps - 1'b1;

    reg [7:0] a_data, b_data;
    wire signed [7:0] weight_data;
    reg signed [31:0] bias_data;
    reg signed [5:0] exponent_data;
    reg read_valid, read_inside, read_last;
    reg product_valid, product_last;
    (* use_dsp = "yes" *) reg signed [16:0] product_data;
    (* use_dsp = "no" *) reg signed [31:0] accumulator;

    // Requantize with nearest-even rounding and saturation. Positive shifts
    // are clipped before shifting, so the 32-bit magnitude cannot overflow.
    function signed [15:0] requantize;
        input signed [31:0] value;
        input signed [5:0] exponent;
        input signed_output;
        reg [31:0] magnitude, scaled, half, remainder, limit;
        reg [4:0] shift;
        begin
            magnitude = value[31] ? -value : value;
            limit = signed_output ? (value[31] ? 32'd32768 : 32'd32767) : 32'd255;
            if (!signed_output && value[31]) begin
                scaled = 0;
            end else if (exponent < 0) begin
                if (exponent == 6'sb100000) begin
                    scaled = 0;
                end else begin
                    shift = -exponent;
                    scaled = magnitude >> shift;
                    half = 32'd1 << (shift - 1'b1);
                    remainder = magnitude & ((half << 1) - 1'b1);
                    if (remainder > half || (remainder == half && scaled[0]))
                        scaled = scaled + 1'b1;
                    if (scaled > limit)
                        scaled = limit;
                end
            end else begin
                shift = exponent[4:0];
                scaled = magnitude > (limit >> shift) ? limit : magnitude << shift;
            end
            requantize = value[31] ? -scaled[15:0] : scaled[15:0];
        end
    endfunction

    wire signed [15:0] quantized = requantize(accumulator, exponent_data, final_layer);
    wire store_feature = state == WRITE_PIXEL && !final_layer;
    wire a_we = busy ? (store_feature && layer[0]) : input_we;
    wire [11:0] a_waddr = busy ? feature_waddr[11:0] : input_waddr;
    wire [7:0] a_wdata = busy ? quantized[7:0] : input_wdata;

    always @(posedge clk) begin
        if (a_we)
            feature_a[a_waddr] <= a_wdata;
        if (state == ISSUE && !layer[0] && in_bounds)
            a_data <= feature_a[feature_raddr[11:0]];
    end
    always @(posedge clk) begin
        if (store_feature && !layer[0])
            feature_b[feature_waddr] <= quantized[7:0];
        if (state == ISSUE && layer[0] && in_bounds)
            b_data <= feature_b[feature_raddr];
    end
    wire [7:0] weight_bank_data [0:2];
    reg [1:0] weight_read_bank;
    always @(posedge clk)
        if (state == ISSUE)
            weight_read_bank <= weight_raddr[14:13];
    assign weight_data = weight_bank_data[weight_read_bank];

    genvar bank;
    generate
        for (bank = 0; bank < 3; bank = bank + 1) begin : weight_banks
            // Power-of-two bank depths allow Vivado 2019.1 to infer BRAM.
            (* ram_style = "block" *) reg [7:0] memory [0:8191];
            reg [7:0] data;
            always @(posedge clk) begin
                if (weight_we && !busy && weight_waddr[14:13] == bank)
                    memory[weight_waddr[12:0]] <= weight_wdata;
                if (state == ISSUE && weight_raddr[14:13] == bank)
                    data <= memory[weight_raddr[12:0]];
            end
            assign weight_bank_data[bank] = data;
        end
    endgenerate
    always @(posedge clk) begin
        if (bias_we && !busy)
            biases[parameter_waddr] <= parameter_wdata;
        if (exponent_we && !busy)
            exponents[parameter_waddr] <= parameter_wdata[5:0];
        if (state == LOAD_PARAM) begin
            bias_data <= biases[parameter_index];
            exponent_data <= exponents[parameter_index];
        end
    end

    reg signed [15:0] first_row;
    wire [8:0] result_waddr = {out_c[3:0], out_x[4:0]};
    wire signed [16:0] row_sum = $signed({first_row[15], first_row}) +
                                 $signed({quantized[15], quantized});
    always @(posedge clk) begin
        if (state == WRITE_PIXEL && final_layer) begin
            if (out_y == 0)
                first_row <= quantized;
            else
                results[result_waddr] <= row_sum;
        end
        if (result_re)
            result_rdata <= results[result_raddr];
    end

    wire [7:0] feature_data = layer[0] ? b_data : a_data;
    always @(posedge clk) begin
        if (!resetn) begin
            read_valid <= 0;
            product_valid <= 0;
        end else begin
            read_valid <= state == ISSUE;
            read_inside <= in_bounds;
            read_last <= issue_last;
            product_valid <= read_valid;
            product_last <= read_last;
            if (read_valid)
                product_data <= $signed({1'b0, read_inside ? feature_data : 8'd0}) * weight_data;
            if (state == BEGIN_PIXEL)
                accumulator <= bias_data;
            else if (product_valid)
                accumulator <= accumulator + {{15{product_data[16]}}, product_data};
        end
    end

    always @(posedge clk) begin
        if (!resetn) begin
            state <= IDLE;
            done <= 0;
            layer <= 0;
        end else begin
            case (state)
                IDLE: if (start) begin
                    done <= 0;
                    layer <= 0;
                    out_c <= 0;
                    out_x <= 0;
                    out_y <= 0;
                    weight_base <= 0;
                    parameter_index <= 0;
                    feature_waddr <= 0;
                    state <= LOAD_PARAM;
                end
                LOAD_PARAM: state <= BEGIN_PIXEL;
                BEGIN_PIXEL: begin
                    in_c <= 0;
                    ky <= 0;
                    kx <= 0;
                    tap <= 0;
                    state <= ISSUE;
                end
                ISSUE: if (issue_last) begin
                    state <= DRAIN;
                end else begin
                    tap <= tap + 1'b1;
                    if (final_layer) begin
                        in_c <= in_c + 1'b1;
                    end else if (kx != 2) begin
                        kx <= kx + 1'b1;
                    end else begin
                        kx <= 0;
                        if (ky == 2) begin
                            ky <= 0;
                            in_c <= in_c + 1'b1;
                        end else
                            ky <= ky + 1'b1;
                    end
                end
                DRAIN: if (product_valid && product_last) state <= WRITE_PIXEL;
                WRITE_PIXEL: begin
                    state <= LOAD_PARAM;
                    feature_waddr <= feature_waddr + 1'b1;
                    // Feature maps are CHW. In the final layer, visit the
                    // two rows of a column consecutively for height summation.
                    if (final_layer && out_y == 0) begin
                        out_y <= 1;
                    end else if (out_x != output_last_x) begin
                        out_x <= out_x + 1'b1;
                        if (final_layer)
                            out_y <= 0;
                    end else if (!final_layer && out_y != output_last_y) begin
                        out_x <= 0;
                        out_y <= out_y + 1'b1;
                    end else begin
                        out_x <= 0;
                        out_y <= 0;
                        if (out_c == output_channels - 1'b1) begin
                            out_c <= 0;
                            feature_waddr <= 0;
                            if (final_layer) begin
                                done <= 1;
                                state <= IDLE;
                            end else
                                layer <= layer + 1'b1;
                        end else
                            out_c <= out_c + 1'b1;
                        weight_base <= weight_base + {6'b0, kernel_taps};
                        parameter_index <= parameter_index + 1'b1;
                    end
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule
