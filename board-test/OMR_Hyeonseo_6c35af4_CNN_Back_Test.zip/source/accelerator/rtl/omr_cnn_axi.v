`timescale 1ns/1ps
// Connect S_AXI to a Zynq PS GP master through an AXI interconnect.
module omr_cnn_axi (
    (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME s_axi_aclk, ASSOCIATED_BUSIF s_axi, ASSOCIATED_RESET s_axi_aresetn" *)
    input  wire        s_axi_aclk,
    input  wire        s_axi_aresetn,
    input  wire [17:0] s_axi_awaddr,
    input  wire [2:0]  s_axi_awprot,
    input  wire        s_axi_awvalid,
    output wire        s_axi_awready,
    input  wire [31:0] s_axi_wdata,
    input  wire [3:0]  s_axi_wstrb,
    input  wire        s_axi_wvalid,
    output wire        s_axi_wready,
    output reg  [1:0]  s_axi_bresp,
    output reg         s_axi_bvalid,
    input  wire        s_axi_bready,
    input  wire [17:0] s_axi_araddr,
    input  wire [2:0]  s_axi_arprot,
    input  wire        s_axi_arvalid,
    output wire        s_axi_arready,
    output reg  [31:0] s_axi_rdata,
    output reg  [1:0]  s_axi_rresp,
    output reg         s_axi_rvalid,
    input  wire        s_axi_rready
);
    localparam OKAY = 2'b00, SLVERR = 2'b10;
    localparam [17:0] CTRL = 18'h00000, STATUS = 18'h00004,
                      BIAS = 18'h01000, EXP = 18'h02000, INPUT = 18'h04000,
                      RESULTS = 18'h08000, WEIGHTS = 18'h10000;

    reg have_aw, have_w, waiting_result;
    reg [17:0] awaddr;
    reg [31:0] wdata;
    reg [3:0] wstrb;
    wire busy, done;
    wire signed [16:0] result_data;

    assign s_axi_awready = s_axi_aresetn && !have_aw && !s_axi_bvalid;
    assign s_axi_wready = s_axi_aresetn && !have_w && !s_axi_bvalid;
    assign s_axi_arready = s_axi_aresetn && !waiting_result && !s_axi_rvalid;

    wire write_commit = s_axi_aresetn && have_aw && have_w && !s_axi_bvalid;
    wire write_allowed = write_commit && !busy && awaddr[1:0] == 0;
    wire control_ok = awaddr == CTRL && wstrb[0];
    wire bias_ok = awaddr >= BIAS && awaddr < BIAS + 18'd492 && wstrb == 4'hf;
    wire exp_ok = awaddr >= EXP && awaddr < EXP + 18'd492 && wstrb[0] &&
                  $signed(wdata[7:0]) >= -8'sd31 && $signed(wdata[7:0]) <= 8'sd31;
    wire input_ok = awaddr >= INPUT && awaddr < RESULTS && wstrb[0] && wdata[7:0] <= 8'd128;
    wire weight_ok = awaddr >= WEIGHTS && awaddr < WEIGHTS + 18'd84640 && wstrb[0];
    wire [17:0] weight_offset = awaddr - WEIGHTS;

    wire read_fire = s_axi_arvalid && s_axi_arready;
    wire read_result = read_fire && !busy && done && s_axi_araddr[1:0] == 0 &&
                       s_axi_araddr >= RESULTS && s_axi_araddr < RESULTS + 18'd1408;

    omr_cnn_core core (
        .clk(s_axi_aclk), .resetn(s_axi_aresetn),
        .start(write_allowed && control_ok && wdata[0]), .busy(busy), .done(done),
        .weight_we(write_allowed && weight_ok), .weight_waddr(weight_offset[16:2]),
        .weight_wdata(wdata[7:0]), .bias_we(write_allowed && bias_ok),
        .exponent_we(write_allowed && exp_ok), .parameter_waddr(awaddr[8:2]),
        .parameter_wdata(wdata), .input_we(write_allowed && input_ok),
        .input_waddr(awaddr[13:2]), .input_wdata(wdata[7:0]),
        .result_re(read_result), .result_raddr(s_axi_araddr[10:2]), .result_rdata(result_data)
    );

    always @(posedge s_axi_aclk) begin
        if (!s_axi_aresetn) begin
            have_aw <= 0;
            have_w <= 0;
            s_axi_bvalid <= 0;
            s_axi_bresp <= OKAY;
        end else begin
            if (s_axi_awready && s_axi_awvalid) begin
                awaddr <= s_axi_awaddr;
                have_aw <= 1;
            end
            if (s_axi_wready && s_axi_wvalid) begin
                wdata <= s_axi_wdata;
                wstrb <= s_axi_wstrb;
                have_w <= 1;
            end
            if (write_commit) begin
                have_aw <= 0;
                have_w <= 0;
                s_axi_bvalid <= 1;
                s_axi_bresp <= write_allowed && (control_ok || bias_ok || exp_ok ||
                                                input_ok || weight_ok) ? OKAY : SLVERR;
            end else if (s_axi_bready)
                s_axi_bvalid <= 0;
        end
    end

    always @(posedge s_axi_aclk) begin
        if (!s_axi_aresetn) begin
            waiting_result <= 0;
            s_axi_rvalid <= 0;
            s_axi_rdata <= 0;
            s_axi_rresp <= OKAY;
        end else begin
            if (read_fire) begin
                if (read_result)
                    waiting_result <= 1;
                else begin
                    s_axi_rvalid <= 1;
                    s_axi_rdata <= s_axi_araddr == STATUS ? {30'd0, done, busy} : 32'd0;
                    s_axi_rresp <= s_axi_araddr == STATUS ? OKAY : SLVERR;
                end
            end else if (waiting_result) begin
                waiting_result <= 0;
                s_axi_rvalid <= 1;
                s_axi_rdata <= {{15{result_data[16]}}, result_data};
                s_axi_rresp <= OKAY;
            end else if (s_axi_rready)
                s_axi_rvalid <= 0;
        end
    end
endmodule
