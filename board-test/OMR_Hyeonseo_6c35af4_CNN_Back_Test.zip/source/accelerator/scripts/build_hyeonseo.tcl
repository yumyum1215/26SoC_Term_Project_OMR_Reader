if {$argc != 2} { error "Usage: build_hyeonseo.tcl TERM_PROJECT OUTPUT_DIR" }
set snapshot [file normalize [lindex $argv 0]]
set output [file normalize [lindex $argv 1]]
set add_accel [file join [file dirname [file normalize [info script]]] add_to_hyeonseo.tcl]
file mkdir $output
create_project -force omr_with_accel [file join $output vivado] -part xc7z020clg484-1
set_property ip_repo_paths [list [file join $snapshot ip_repo]] [current_project]
update_ip_catalog
set sources [file join $snapshot OMR_state_change OMR_state_change.srcs]
import_files [glob -directory [file join $sources sources_1 new] *.v *.vhd]
import_files -fileset constrs_1 [glob -directory [file join $sources constrs_1 new] *.xdc]
update_compile_order -fileset sources_1
import_files [file join $sources sources_1 bd system system.bd]
set bd [get_files system.bd]
open_bd_design $bd
source $add_accel
generate_target all $bd
add_files -norecurse [make_wrapper -files $bd -top]
set_property top system_wrapper [current_fileset]
update_compile_order -fileset sources_1
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1
if {![string match "*Complete*" [get_property STATUS [get_runs impl_1]]]} {
    error "Integrated build failed: [get_property STATUS [get_runs impl_1]]"
}
open_run impl_1
report_utilization -file [file join $output integrated_utilization.rpt]
report_timing_summary -file [file join $output integrated_timing.rpt]
set bit [file join [get_property DIRECTORY [get_runs impl_1]] system_wrapper.bit]
set hwdef [file join $output omr_with_accel.hwdef]
file copy -force $bit [file join $output omr_with_accel.bit]
write_hwdef -force -file $hwdef
write_sysdef -hwdef $hwdef -bitfile $bit -file [file join $output omr_with_accel.hdf]
puts "HYEONSEO OMR ACCELERATOR BUILD COMPLETE"
