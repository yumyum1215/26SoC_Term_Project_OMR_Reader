# Source in Vivado 2019.1 with the Hyeonseo OMR project and system.bd open.
set accel_dir [file normalize [file join [file dirname [info script]] ..]]
if {[current_bd_design -quiet] eq ""} { error "Open the OMR system.bd block design first" }
set interconnect [get_bd_cells -quiet ps7_0_axi_periph]
set address_space [get_bd_addr_spaces -quiet processing_system7_0/Data]
set clock [get_bd_pins -quiet processing_system7_0/FCLK_CLK0]
set reset [get_bd_pins -quiet rst_ps7_0_50M/peripheral_aresetn]
if {[llength $interconnect] != 1 || [llength $address_space] != 1 ||
    [llength $clock] != 1 || [llength $reset] != 1} {
    error "Expected the Hyeonseo OMR AXI interconnect, PS address space and clock/reset"
}
if {[llength [get_bd_cells -quiet omr_cnn_0]] != 0} {
    error "The block design already contains omr_cnn_0"
}
# 256 KiB aligned, above the LCD's 0x43C00000 segment.
set new_base 0x43C40000
set new_limit 0x43C80000
foreach mapped [get_bd_addr_segs -of_objects $address_space] {
    set offset [get_property OFFSET $mapped]
    set range [get_property RANGE $mapped]
    if {[regexp -nocase {^([0-9]+)([kmg])$} $range -> amount suffix]} {
        set scale [dict get {k 1024 m 1048576 g 1073741824} [string tolower $suffix]]
        set range [expr {$amount * $scale}]
    }
    if {$offset < $new_limit && $offset + $range > $new_base} {
        error "Requested accelerator address range overlaps $mapped"
    }
}
foreach filename {omr_cnn_core.v omr_cnn_axi.v} {
    if {[get_files -quiet $filename] eq ""} {
        import_files [file join $accel_dir rtl $filename]
    }
}
update_compile_order -fileset sources_1
set count [get_property CONFIG.NUM_MI $interconnect]
set branch [format "M%02d" $count]
set_property CONFIG.NUM_MI [expr {$count + 1}] $interconnect
create_bd_cell -type module -reference omr_cnn_axi omr_cnn_0
connect_bd_intf_net [get_bd_intf_pins [format "ps7_0_axi_periph/%s_AXI" $branch]] \
    [get_bd_intf_pins omr_cnn_0/s_axi]
connect_bd_net $clock [get_bd_pins [format "ps7_0_axi_periph/%s_ACLK" $branch]] \
    [get_bd_pins omr_cnn_0/s_axi_aclk]
connect_bd_net $reset [get_bd_pins [format "ps7_0_axi_periph/%s_ARESETN" $branch]] \
    [get_bd_pins omr_cnn_0/s_axi_aresetn]
assign_bd_address -offset $new_base -range 256K -target_address_space $address_space \
    [get_bd_addr_segs -of_objects [get_bd_intf_pins omr_cnn_0/s_axi]]
validate_bd_design
save_bd_design
puts "OMR CNN accelerator added to $branch at 0x43C40000"
