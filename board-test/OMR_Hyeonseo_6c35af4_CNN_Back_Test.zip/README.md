# 현서 브랜치 OMR과 FPGA CNN · 주관식 2문항 시험

현서 브랜치 `6c35af47b11329b66e418d6c65bea5b26ddcafe5`를 사용했다. 기준 `22be1692993d855aa0730d52d91014f3b9c22aa2` 이후 21커밋이 추가됐다. [GitHub 비교](https://github.com/yumyum1215/26SoC_Term_Project_OMR_Reader/compare/22be1692993d855aa0730d52d91014f3b9c22aa2...6c35af47b11329b66e418d6c65bea5b26ddcafe5)

- 앞·뒷면 촬영 사진을 각각 약 5초 보여 준다. 앞면을 읽은 뒤 객관식 점수를 먼저 보여 주고, 뒷면을 읽으면 합계를 표시한다. 학생 ID는 카드의 학년·반·번호에서 읽는다.
- 최신 카메라 초기화와 TFT 색/방향 보정, 과목별 기록 폴더 및 과목코드 `10` 시험 모드를 유지한다.
- 새 앱의 뒷면 처리는 `OMRCNN.BIN`을 로드하면 `0x43C40000`의 FPGA CNN을 호출한다. SD 카드에 파일이 없으면 기존 ARM 판독기를 호출하며 UART에 `ARM`을 표시한다. 파일이 있지만 검증에 실패하면 주관식을 `REVIEW`로 처리한다.
- 주관식 정답은 `17`, `101`이고 각 10점이다. 객관식은 최신 브랜치의 TEST 예제 10문항과 문항당 8점을 그대로 사용한다.

## 학습 가중치

ZIP의 `sd-test/OMRCNN.BIN`은 서버에서 가져온 `integer_graph.json`과 `integer_weights.npz`로 만들었다. 가중치를 교체할 때는 새 export 폴더를 아래 명령에 전달한다. Python에 NumPy가 필요하다.

```powershell
python source/accelerator/scripts/export_params.py path/to/export --out model --binary
```

생성된 `model/OMRCNN.BIN`을 FAT32 SD 카드 루트에 넣고 앱을 다시 시작한다. 가중치가 바뀌면 ELF와 비트스트림을 다시 만들 필요가 없다.

## 보드에서 시험

1. FAT32 SD 카드 루트에 `sd-test/KEY.TXT`, `sd-test/KEY10.TXT`, `sd-test/OMRCNN.BIN`을 복사한다. 보정해 둔 `KEY.TXT`가 있으면 그 파일을 사용한다. `KEY10.TXT`의 2·3번째 줄은 최신 브랜치 예제의 좌표다. 실제 `BACK.BMP`에서 답란과 다르면 `left top right bottom`을 수정한다. 오른쪽과 아래 좌표는 포함하지 않는다.
2. 카드 앞면에 학년·반·번호, 과목코드 `10`, 객관식 1번 ①을 마킹한다. 뒷면 두 시험 답란에 `17`, `101`을 쓴다.
3. CAMERA1, UART 및 JTAG을 연결하고 UART 115200 8N1을 연다. SDK 2019.1 명령 프롬프트에서 ZIP을 푼 폴더로 이동해 `xsct run_jtag.tcl`을 실행한다. FPGA 모드에서는 UART에 `BACK OCR FPGA: OMRCNN.BIN loaded`가 표시된다.
4. `READY - PRESS 1`에서 1번 버튼을 눌러 앞면을 찍고 객관식 8점을 확인한다. 뒷면을 정렬하고 `READY - PRESS 2`에서 2번 버튼을 누른다. 약 5초 사진 표시 후 판독 결과가 UART에 출력된다.

두 답을 정확하게 인식했을 때 아래처럼 표시된다.

```text
BACK Q1 FPGA READ=17 KEY=17 POINTS=10/10
BACK Q2 FPGA READ=101 KEY=101 POINTS=10/10
BACK SUBTOTAL 20/20
```

위와 같이 객관식 1번만 맞혔다면 최종 점수는 28점이다. `DATA/S10/<학생 ID>/RESULT.TXT`의 `ANSWER=`에서 `/` 뒤의 두 인식값을 확인한다. 판독 검토로 분류된 경우 같은 위치의 `REVIEW.TXT` 및 `BACK.BMP`를 확인한다.

## 다시 빌드

ZIP을 푼 폴더에서 Vivado 2019.1 명령 프롬프트로 실행한다.

```powershell
vivado -mode batch -source source/accelerator/scripts/build_hyeonseo.tcl -tclargs source/hyeonseo/term_project build
.\source\app\OMR_state_change\build_sdk.ps1 -SdkRoot 'C:/Xilinx/SDK/2019.1' -HardwareDefinition (Resolve-Path .\build\omr_with_accel.hdf)
```

Vivado 프로젝트는 `build/vivado/omr_with_accel.xpr`에 생성된다. Vivado XSim에서는 서버 가중치를 쓰고 합성 MNIST 두 답란의 출력 점수 704개를 Python 정수 모델과 비교했다. 이 PC에는 JTAG 보드가 연결되지 않아 버튼·카메라 촬영은 실보드에서 시험하지 못했다.
