# Run the integrated Hyeonseo OMR application with SDK 2019.1.
set hardware [file join [file dirname [file normalize [info script]]] hardware]
foreach filename {omr_with_accel.bit ps7_init.tcl OMR_state_change_app.elf} {
    if {![file isfile [file join $hardware $filename]]} { error "Missing $filename" }
}
connect
targets -set -nocase -filter {name =~ "xc7z020*"}
fpga -file [file join $hardware omr_with_accel.bit]
targets -set -nocase -filter {name =~ "*Cortex-A9*#0"}
rst -processor
namespace eval xsdb [list source [file join $hardware ps7_init.tcl]]
namespace eval xsdb {ps7_init; ps7_post_config}
dow [file join $hardware OMR_state_change_app.elf]
con
disconnect
